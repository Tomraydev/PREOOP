#ifndef Max
#define Max

#include"Typy.h"

float Max (ciag dane, rozmiarCiagu rozmiar);

#endif
