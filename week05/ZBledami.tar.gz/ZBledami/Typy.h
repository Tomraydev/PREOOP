#include"InicjalizujCiagGeometryczny.h"

typedef int rozmiarCiagu;
typedef float typCiagu;
typedef typCiagu* ciag;
typedef float (*operacja)(const ciag dane, rozmiarCiagu rozmiar);
