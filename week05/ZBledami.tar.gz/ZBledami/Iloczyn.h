#pragma once
#include"Typy.h"

float Iloczyn (const ciag dane, rozmiarCiagu rozmiar);
