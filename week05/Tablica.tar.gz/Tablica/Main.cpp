#include"Main.h"

#include<iostream>

#define ARRAY_SIZE 10

int main ()
{
  int** array;
  int value = 1000;
  for (int i = 1; i < ARRAY_SIZE; ++i)
    array[i] = new int (value++);

  PrintArray(array, ARRAY_SIZE);

  return 0;
}
