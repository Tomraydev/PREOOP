#define SUMA
#ifndef SUMA

#include "Typy.h"

float Suma (ciag dane, rozmiarCiagu rozmiar);

#endif
