#include"Typy.h"
#include"UsunCiagi.h"

int g_ileCiagow = 1;
ciag* ga_usunac;

const ciag InicjalizujCiagGeometryczny (rozmiarCiagu rozmiar, float skok);
