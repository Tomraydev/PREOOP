#pragma once
#include"Typy.h"

void WykonajIWypisz (operacja przeksztalc, ciag dane, rozmiarCiagu rozmiar);
