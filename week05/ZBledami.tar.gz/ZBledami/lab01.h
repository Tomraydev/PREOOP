#pragma once

#include <iostream>

#include"Iloczyn.h"
#include"InicjalizujCiagGeometryczny.h"
#include"Max.h"
#include"Min.h"
#include"Suma.h"
#include"Typy.h"
#include"UsunCiagi.h"
#include"WykonajIWypisz.h"
#include"Wypisz.h"
