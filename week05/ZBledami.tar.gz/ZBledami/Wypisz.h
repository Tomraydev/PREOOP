#include"Typy.h"

void Wypisz(ciag dane, rozmiarCiagu ile);
