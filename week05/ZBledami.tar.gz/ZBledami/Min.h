#ifndef MIN
#define MIN

#include"Typy.h"

float Min (ciag dane, rozmiarCiagu rozmiar);

#endif
