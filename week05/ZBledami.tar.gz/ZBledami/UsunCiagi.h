#pragma once
#include"InicjalizujCiagGeometryczny.h"

void UsunCiagi();
