#include"Typy.h"
#include"WykonajIWypisz.h"
#include<iostream>

void WykonajIWypisz (operacja przeksztalc, ciag dane, rozmiarCiagu rozmiar)
{
  std::cout <<(*przeksztalc)(dane, rozmiar)<<"\n";
}

